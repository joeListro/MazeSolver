/* ***  Author:  Joe Listro
*  Last Update:  April 18, 2015
*     Filename:  Maze.h
*
*  Certification of Authenticity:
*     I certify that this assignment is entirely my own work.
**********************************************************************/

#include <sstream>
#include "bitmap_image.hpp"
#include "bst.h"
#include "mazeHelper.h"

class Maze
{
private:
	int mazeArray[3202][3202];
	mazeBlock start, end;
	bitmap_image *bMaze;
	unsigned int mazeWidth, mazeHeight;
	stringstream saveFileName;

	bool recursiveSolve(mazeBlock &curBlock, Direction prevDir);
	bool isValidBlock(mazeBlock &curBlock, Direction prevDir);
	void visitBlock(mazeBlock &curBlock, Direction prevDir);
	void paintCorrectPath(mazeBlock &curBlock);
	void paintStartLocation();
	void paintEndLocation();
public:
	Maze();
	Maze(string srcFileName);
	~Maze();
	void load(string filename);
	void solveIt();
	void saveBMP();
};

Maze::Maze()
{
	string filename;
	cout << "What is the file name of the maze you wish to solve: \n";
	cin >> filename;
	saveFileName.clear();
	saveFileName.str() = filename;
	load(filename);
	mazeWidth = bMaze->width();
	mazeHeight = bMaze->height();
}

Maze::Maze(string srcFileName)
{
	load(srcFileName);
}

Maze::~Maze()
{
	saveBMP();
	delete bMaze;
}

void Maze::load(string filename)
{
	bMaze = new bitmap_image(filename);
	unsigned char red = 0, green = 0, blue = 0;
	int height = bMaze->height();
	saveFileName.str() = filename;

	for (int x = 0; x < height; x++)
	{
		for (int y = 0; y < height; y++)
		{
			bMaze->get_pixel(x, y, red, green, blue);
			if ((red == 255) && (green == 255) && (blue == 255))
			{
				mazeArray[x][y] = 0;
			}
			else if ((red == 0) && (green == 0) && (blue == 0))
			{
				mazeArray[x][y] = 1;
			}
			else
			{
				cout << "ERROR!";
			}
		}
	}
	mazeWidth = bMaze->width();
	mazeHeight = bMaze->height();
	start.moveBlock(((mazeWidth / 2) - 15), 2);
	end.moveBlock(((mazeWidth / 2) + 1), (mazeHeight - 16));
}

void Maze::solveIt()
{
	mazeBlock curBlock(start);
	curBlock.moveUp();
	visitBlock(curBlock, Up);
	curBlock.moveDown();
	bool solved = recursiveSolve(curBlock, Down);
	return;
}

bool Maze::recursiveSolve(mazeBlock &curBlock, Direction prevDir)
{
	if (curBlock == end) {
		return true; 
	}
	if (isValidBlock(curBlock, prevDir)) {
		visitBlock(curBlock, prevDir);
		curBlock.moveLeft();
		if (recursiveSolve(curBlock, Left)) { // Recalls function one to the left
			curBlock.moveRight();
			paintCorrectPath(curBlock);
			return true;
		}
		curBlock.moveRight();
		curBlock.moveRight();
		if (recursiveSolve(curBlock, Right)) { // Recalls function one to the right
			curBlock.moveLeft();
			paintCorrectPath(curBlock);
			return true;
		}
		curBlock.moveLeft();
		curBlock.moveUp();
		if (recursiveSolve(curBlock, Up)) { // Recalls function one up
			curBlock.moveDown();
			paintCorrectPath(curBlock);
			return true;
		}
		curBlock.moveDown();
		curBlock.moveDown();
		if (recursiveSolve(curBlock, Down)) { // Recalls function one down
			curBlock.moveUp();
			paintCorrectPath(curBlock);
			return true;
		}
		curBlock.moveUp();
	}
	return false;
}

bool Maze::isValidBlock(mazeBlock &curBlock, Direction prevDir)
{
	unsigned int x, y;
	switch (prevDir)
	{
	case Left:
		x = curBlock.xStart;
		for (y = curBlock.yStart; y <= curBlock.yEnd; y++)
		{
			if ((mazeArray[x][y] == wasHere) || (mazeArray[x][y] == Wall)) { 
				return false; 
			}
		}
		break;
	case Right:
		x = curBlock.xEnd;
		for (y = curBlock.yStart; y <= curBlock.yEnd; y++)
		{
			if ((mazeArray[x][y] == wasHere) || (mazeArray[x][y] == Wall)) { 
				return false; 
			}
		}
		break;
	case Up:
		y = curBlock.yStart;
		for (x = curBlock.xStart; x <= curBlock.xEnd; x++)
		{
			if ((mazeArray[x][y] == wasHere) || (mazeArray[x][y] == Wall)) { 
				return false; 
			}
		}
		break;
	case Down:
		y = curBlock.yEnd;
		for (x = curBlock.xStart; x <= curBlock.xEnd; x++)
		{
			if ((mazeArray[x][y] == wasHere) || (mazeArray[x][y] == Wall)) { 
				return false; 
			}
		}
		break;
	}
	return true;
}


void Maze::visitBlock(mazeBlock &curBlock, Direction prevDir)
{
	unsigned int x, y;
	switch (prevDir)
	{
	case Left:
		x = curBlock.xStart;
		for (y = curBlock.yStart; y <= curBlock.yEnd; y++)
		{
			mazeArray[x][y] = wasHere;
		}
		break;
	case Right:
		x = curBlock.xEnd;
		for (y = curBlock.yStart; y <= curBlock.yEnd; y++)
		{
			mazeArray[x][y] = wasHere;
		}
		break;
	case Up:
		y = curBlock.yStart;
		for (x = curBlock.xStart; x <= curBlock.xEnd; x++)
		{
			mazeArray[x][y] = wasHere;
		}
		break;
	case Down:
		y = curBlock.yEnd;
		for (x = curBlock.xStart; x <= curBlock.xEnd; x++)
		{
			mazeArray[x][y] = wasHere;
		}
		break;
	}
}

void Maze::paintCorrectPath(mazeBlock &curBlock)
{
	unsigned int x = curBlock.xStart + 5, y = curBlock.yStart + 5, width = 4, height = 4, red = 0, green = 255, blue = 0;

	if (bMaze->set_region(x, y, width, height, red, green, blue)) { return; }
	else {
		cout << "ERROR\n";
		return;
	}
}

void Maze::saveBMP()
{
	//Paint Start and End
	paintStartLocation();
	paintEndLocation();

	saveFileName << "_solved.bmp";

	// Save file
	bMaze->save_image(saveFileName);
}



void Maze::paintStartLocation()
{
	unsigned int x = start.xStart + 3, y = start.yStart + 3, width = 8, height = 8, red = 0, green = 0, blue = 255;

	if (bMaze->set_region(x, y, width, height, red, green, blue)) { return; }
	else {
		cout << "ERROR\n";
		return;
	}
}

void Maze::paintEndLocation()
{
	unsigned int x = end.xStart + 3, y = end.yStart + 3, width = 8, height = 8, red = 255, green = 0, blue = 0;

	if (bMaze->set_region(x, y, width, height, red, green, blue))	{ return; }
	else {
		cout << "ERROR\n";
		return;
	}
}