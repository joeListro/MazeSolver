#ifndef _BST_H
#define _BST_H

#include <iostream>
#include "bst-node.h"
#include "queue.h"

using namespace std;

template <class T>
class BST
{
private:
	BST_Node<T> *mRootNode;

	BST(T data, BST_Node<T> *left, BST_Node<T> *right);

	bool bfs(Queue<BST_Node<T>*> *queue, const T &searchKey);
	void destroySubtree(BST_Node<T> *node);
	bool dfs(BST_Node<T> *node, const T &searchKey);
	bool bs(BST_Node<T> *node, const T &searchKey);
	void displayInOrder(BST_Node<T> *node);
	void displayPreOrder(BST_Node<T> *node);
	void displayPostOrder(BST_Node<T> *node);
	void displayTree(BST_Node<T> *node, int tab);
	void getHeight(BST_Node<T> *node, int &max, int layer);
	void insert(BST_Node<T> *&node, const T &data);
	void leavesCount(BST_Node<T> *node, int &count);
	void nodesCount(BST_Node<T> *node, int &count);
	void makeDeletion(BST_Node<T> *&node);
	void remove(BST_Node<T> *&node, const T &searchKey);

public:
	BST();
	~BST();

	bool bfs(T searchKey);
	bool dfs(T searchKey);
	int  getHeight();
	void insert(T data);
	bool isEmpty();
	bool isExists(T searchKey);
	int  leavesCount();
	int  nodesCount();
	void remove(T searchKey);
	void showInOrder();
	void showPreOrder();
	void showPostOrder();
	void showTree();
	void printPath(T searchKey);
};


template <class T>
BST<T>::BST()
{
	mRootNode = NULL;
}

template <class T>
BST<T>::BST(T data, BST_Node<T> *left = NULL, BST_Node<T> *right = NULL)
{
	BST_Node<T> *newNode;

	newNode = new BST_Node(data, left, right);
	if (newNode != NULL)
		mRootNode = newNode;
}


template <class T>
BST<T>::~BST()
{
	destroySubtree(mRootNode);
}

template <class T>
bool BST<T>::bfs(Queue<BST_Node<T>*> *queue, const T &searchKey)
{
	BST_Node<T> tNode = NULL;
	while (!queue->isEmpty())
	{  
		tNode = queue->dequeue();
		cout << tNode << endl;
		if (searchKey == tNode.mData)
		{
			cout << "Success! " << searchKey << " found using breath-first search.\n"
			return true;
		}
		else
		{
			if (tNode.mLeft != NULL)
			{
				queue->enqueue(tNode.mLeft);
			}
			if (tNode.mRight != NULL)
			{
				queue->enqueue(tNode.mRight);
			}
		}
	}
	cout << "Error! " << searchKey << " not found!\n";
	return false;
}

template <class T>
void BST<T>::destroySubtree(BST_Node<T> *node)
{
	if (node == NULL)
		return;

	destroySubtree(node->mLeft);
	destroySubtree(node->mRight);

	// Delete the node at the root.
	delete node;
}

template <class T>
bool BST<T>::dfs(BST_Node<T> *node, const T &searchKey)
{
	if (node)
	{
		cout << node->mData << endl;
		if (node->mData == searchKey)
		{
			cout << "Success! " << searchKey << " found using the depth-first search.\n"
			return true;
		}
		else
		{
			if (node->mLeft)
			{
				dfs(node->mLeft, searchKey);
			}
			else if (node->mRight)
			{
				dfs(node->mRight, searchKey);
			}
		}
	}
	return false;
}

template <class T>
bool BST<T>::bs(BST_Node<T> *node, const T &searchKey) // Binary Search
{
	if (node)
	{
		if (node->mData == searchKey)
		{
			cout << node->mData << endl << "Success! " << searchKey << " found using the direct binary search.\n";
			return true;
		}
		else if (node->mData < searchKey)
		{
			if (node->mRight)
			{
				cout << node->mData << endl;
				bs(node->mRight, searchKey);
			}
		}
		else if (node->mData > searchKey)
		{
			if (node->mLeft)
			{
				cout << node->mData << endl;
				bs(node->mLeft, searchKey);
			}
		}
	}
	else
	{
		cout << "Error! Binary Search was unable to find " << searchKey << "!\n";
	}
}

template <class T>
void BST<T>::displayInOrder(BST_Node<T> *node)
{
	if (node != NULL)
	{
		displayInOrder(node->mLeft);
		cout << node->mData << "  ";
		displayInOrder(node->mRight);
	}
}


template <class T>
void BST<T>::displayPreOrder(BST_Node<T> *node)
{
	if (node != NULL)
	{
		cout << node->mData << "  ";
		displayPreOrder(node->mLeft);
		displayPreOrder(node->mRight);
	}
}


template <class T>
void BST<T>::displayPostOrder(BST_Node<T> *node)
{
	if (node != NULL)
	{
		displayPostOrder(node->mLeft);
		displayPostOrder(node->mRight);
		cout << node->mData << "  ";
	}
}

template <class T>
void BST<T>::displayTree(BST_Node<T> *node, int tab)
{
	if (node)
	{
		for (int i = 0; i < tab; i++)
		{
			cout << "\t";
		}
		cout << node->mData << endl;
		tab++;
		displayTree(node->mLeft, tab);
		displayTree(node->mRight, tab);
	}
	return;
}

template <class T>
void BST<T>::getHeight(BST_Node<T> *node, int &max, int layer)
{  
	if (node != NULL)
	{
		if (node->mLeft != NULL)
		{
			layer++;
			getHeight(node->mLeft, max, layer);
		}
		else if (node->mRight != NULL)
		{
			layer++;
			getHeight(node->mRight, max, layer);
		}
		else
		{
			if (layer > max)
			{
				max = layer;
				return;
			}
			else
			{
				return;
			}
		}
	}
}

template <class T>
void BST<T>::insert(BST_Node<T> *&node, const T &data)
{
	// If the tree is empty, make a new node and make it 
	// the root of the tree.
	if (node == NULL)
	{
		node = new BST_Node<T>(data);
		return;
	}

	// If num is already in tree: return.
	if (node->mData == data)
		return;

	// The tree is not empty: insert the new node into the
	// left or right subtree.
	if (data < node->mData)
		insert(node->mLeft, data);
	else
		insert(node->mRight, data);
}


template <class T>
void BST<T>::leavesCount(BST_Node<T> *node, int &count)
{
	if (node)
	{
		if ((node->mLeft == NULL) && (node->mRight == NULL))
		{
			count++;
		}
		leavesCount(node->mLeft, count);
		leavesCount(node->mRight, count);
	}
	return;
}

template <class T>
void BST<T>::nodesCount(BST_Node<T> *node, int &count)
{
	if (node)
	{
		count++;
		nodesCount(node->mLeft, count);
		nodesCount(node->mRight, count);
	}
	return;
}

template <class T>
void BST<T>::makeDeletion(BST_Node<T> *&node)
{
	// Used to hold node that will be deleted.
	BST_Node<T> *nodeToDelete = node;

	// Used to locate the  point where the 
	// left subtree is attached.
	BST_Node<T> *attachPoint;

	if (node->mRight == NULL)
	{
		// Replace tree with its left subtree. 
		node = node->mLeft;
	}
	else if (node->mLeft == NULL)
	{
		// Replace tree with its right subtree.
		node = node->mRight;
	}
	else
		//The node has two children
	{
		// Move to right subtree.
		attachPoint = node->mRight;

		// Locate the smallest node in the right subtree
		// by moving as far to the left as possible.
		while (attachPoint->mLeft != NULL)
			attachPoint = attachPoint->mLeft;

		// Attach the left subtree of the original tree
		// as the left subtree of the smallest node 
		// in the right subtree.
		attachPoint->mLeft = node->mLeft;

		// Replace the original tree with its right subtree.
		node = node->mRight;
	}

	// Delete root of original tree
	delete nodeToDelete;
}

template <class T>
void BST<T>::remove(BST_Node<T> *&node, const T &searchKey)
{
	if (node == NULL)
		return;
	else if (node->mData > searchKey)
		remove(node->mLeft, searchKey);
	else if (node->mData < searchKey)
		remove(node->mRight, searchKey);
	else
		// We have found the node to delete.
		makeDeletion(node);
}

template <class T>
bool BST<T>::bfs(T searchKey)
{
	Queue<T> queue;
	queue.enqueue(mRootNode);
	cout << "Breath-First Search\ncall stack\n-----------\nRoot node: ";
	return bfs(queue, searchKey);
}

template <class T>
bool BST<T>::dfs(T searchKey)
{
	cout << "Depth-First Search\ncall stack\n-----------\nRoot node: ";
	bool found = false;
	found = dfs(mRootNode, searchKey);
	if (!found)
	{
		cout << "Error! " << searchKey << " not found in the binary tree.\n";
		return false;
	}
	else if (found)
	{
		return true;
	}
}

template <class T>
int  BST<T>::getHeight()
{
	int height = 0;
	getHeight(mRootNode, height, 0);
	return height;
}

template <class T>
void BST<T>::insert(T data)
{
	insert(mRootNode, data);
}

template <class T>
bool BST<T>::isEmpty()
{
	return (mRootNode == NULL);
}

template <class T>
bool BST<T>::isExists(T searchKey)
{
	BST_Node<T> *tmp = mRootNode;

	while (tmp != NULL)
	{
		if (tmp->mData == searchKey)
			return true;
		else if (tmp->mData > searchKey)
			tmp = tmp->mLeft;
		else
			tmp = tmp->mRight;
	}
	return false;
}


template <class T>
int BST<T>::leavesCount()
{
	int count = 0;
	leavesCount(mRootNode, count);
	return count;
}

template <class T>
int BST<T>::nodesCount()
{
	int count = 0;
	nodesCount(mRootNode, count);
	return count;
}

template <class T>
void BST<T>::remove(T searchKey)
{
	remove(mRootNode, searchKey);
}

template <class T>
void BST<T>::showInOrder()
{
	displayInOrder(mRootNode);
}


template <class T>
void BST<T>::showPreOrder()
{
	displayPreOrder(mRootNode);
}


template <class T>
void BST<T>::showPostOrder()
{
	displayPostOrder(mRootNode);
}

template <class T>
void BST<T>::showTree()
{
	if (mRootNode)
	{
		displayTree(mRootNode, 0);
	}
	return;
}

template <class T>
void BST<T>::printPath(T searchKey)
{
	cout << "Print Path, direct Binary Search\nPath to searchKey\n-----------\nRoot node: ";
	bool found = bs(mRootNode, searchKey);
	return;
}

#endif _BST_H