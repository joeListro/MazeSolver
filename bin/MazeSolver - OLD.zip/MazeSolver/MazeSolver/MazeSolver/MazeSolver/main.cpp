/* ***  Author:  Joe Listro
*  Last Update:  April 18, 2015
*     Filename:  main.cpp
*
*  Certification of Authenticity:
*     I certify that this assignment is entirely my own work.
**********************************************************************/

#include "Maze.h"

using namespace std;

int main() {
	cout << "Place all maze image files in ~/MazeSolver/MazeSolver/Maze Images/\n";
	Maze tMaze();

	tMaze.solveIt();
	tMaze.saveBMP();

	return 0;
}